#include <gtk/gtk.h>


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton9_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);



void
on_button2quitter_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1ajouter_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebutton1_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebutton2_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3afficher_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeviewgestionstock_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button1modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2supprimer_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3retour_clicked               (GtkButton       *button,
                                        gpointer         user_data);


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button2retour2_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3repture_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button1login_clicked                (GtkButton       *button,
                                        gpointer         user_data);



void
on_buttongotoajouter_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongotomodifier_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongotoafficher_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongotosupprimer_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1recherche_clicked            (GtkButton       *button,
                                        gpointer         user_data);
